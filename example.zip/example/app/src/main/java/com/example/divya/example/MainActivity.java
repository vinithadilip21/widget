package com.example.divya.example;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.CompletionInfo;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
 ToggleButton tbutton;
 CheckBox cbox;
 RadioButton radioButton;
 TextView textcbox,textView,textseekbar;
 SeekBar seekbar;
 Switch switch1;
 RelativeLayout r1;
 ImageView image;
 RadioGroup rg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         tbutton=(ToggleButton)findViewById(R.id.toggleButton);
         cbox=(CheckBox)findViewById(R.id.checkBox);
         radioButton=(RadioButton)findViewById(R.id.radioButton);

        textcbox=(TextView)findViewById(R.id.textView );
        textView=(TextView)findViewById(R.id.textView2);

        textseekbar=(TextView)findViewById(R.id.textView4);
        r1=(RelativeLayout)findViewById(R.id.R1);
        switch1=(Switch)findViewById(R.id.switch1);
        image=(ImageView)findViewById(R.id.imageView4);
        rg=(RadioGroup)findViewById(R.id.radioGroup);
        tbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(tbutton.isChecked())
                {
                    r1.setBackgroundResource(R.drawable.images);
                }
                else
                {
                    r1.setBackgroundResource(R.drawable.image2);
                }

            }
        });
     cbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
         @Override
         public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
             if(isChecked)
             {
                 textcbox.setText("Checkbox is selected");
             }
             else
             {

                 textcbox.setText("Checkbox is not selected");
             }
         }
     });



     seekbar=(SeekBar)findViewById(R.id.seekBar);
     seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
         @Override
         public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
             textseekbar.setTextSize(progress);
         }

         @Override
         public void onStartTrackingTouch(SeekBar seekBar) {

         }

         @Override
         public void onStopTrackingTouch(SeekBar seekBar) {

         }


     });
     switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
         @Override
         public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
             if(isChecked) {

                 Animation startRotateAnimation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.android_rotate_animation);

                 image.startAnimation(startRotateAnimation);

             }


         }
     });

    }
    public void gender(View v)
    {
        int radioid=rg.getCheckedRadioButtonId();
        radioButton=findViewById(radioid);
        textView.setText(radioButton.getText());

    }

}
